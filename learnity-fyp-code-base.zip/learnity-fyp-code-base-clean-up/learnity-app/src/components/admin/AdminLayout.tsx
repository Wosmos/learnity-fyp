'use client';

/**
 * Unified Admin Layout Component
 * Provides consistent layout for all admin pages with sidebar navigation
 * Implements proper authentication protection and responsive design
 */

import React from 'react';
import { useAuthenticatedApi } from '@/hooks/useAuthenticatedFetch';
import { AdminAuthenticatedLayout } from '@/components/layout/AppLayout';
import { AdminSidebar } from './AdminSidebar';

import { Breadcrumbs } from '@/components/shared/Breadcrumbs';

interface AdminLayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  showBackButton?: boolean;
  backHref?: string;
  actions?: React.ReactNode;
}

interface QuickStats {
  activeUsers: number;
  todaysLogins: number;
  securityEvents: number;
  systemStatus: string;
}

export class AdminStatsService {
  private static instance: AdminStatsService;

  public static getInstance(): AdminStatsService {
    if (!AdminStatsService.instance) {
      AdminStatsService.instance = new AdminStatsService();
    }
    return AdminStatsService.instance;
  }

  public async fetchQuickStats(api: {
    post: (
      url: string,
      data: Record<string, string>
    ) => Promise<Record<string, number>>;
  }): Promise<QuickStats> {
    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setHours(startDate.getHours() - 24);

      const summary = await api.post('/api/admin/security/summary', {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      });

      return {
        activeUsers: summary.uniqueUsers || 0,
        todaysLogins: summary.successfulLogins || 0,
        securityEvents: summary.securityEvents || 0,
        systemStatus: 'Healthy',
      };
    } catch (error) {
      console.error('Failed to fetch admin stats:', error);
      return {
        activeUsers: 0,
        todaysLogins: 0,
        securityEvents: 0,
        systemStatus: 'Unknown',
      };
    }
  }
}

export function AdminLayout({
  children,
  title,
  description,
  showBackButton = false,
  backHref = '/admin',
  actions,
}: AdminLayoutProps) {
  const api = useAuthenticatedApi();

  // Stats service usage removed as the new sidebar doesn't display stats
  // const statsService = AdminStatsService.getInstance();
  // useEffect fetching stats removed

  return (
    <AdminAuthenticatedLayout>
      <div className='min-h-screen bg-gray-50 flex'>
        {/* Sidebar */}
        <AdminSidebar />

        {/* Main Content Area */}
        <div className='flex-1 flex flex-col min-w-0'>
          {/* Dynamic Breadcrumbs */}
          <Breadcrumbs />

          {/* Main Content */}
          <main className='flex-1 overflow-auto'>
            <div className='p-2'>{children}</div>
          </main>
        </div>
      </div>
    </AdminAuthenticatedLayout>
  );
}

export default AdminLayout;
