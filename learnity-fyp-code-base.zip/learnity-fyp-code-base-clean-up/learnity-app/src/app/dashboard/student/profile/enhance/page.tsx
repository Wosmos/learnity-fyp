import React from 'react';
import ProfileEnhancePage from '@/app/profile/enhance/page';

const page = () => {
  return <ProfileEnhancePage />;
};

export default page;
